import { ethers } from "ethers";
import dotenv from "dotenv";
dotenv.config();
import { calcNextBlockBaseFee } from "./utils.js";
import IUniswapV2Pair from "./ABIs/IUniswapV2Pair.js";
import IERC20 from "./ABIs/IERC20.js";
import Web3 from "web3";
// Const addresses on ethereum
export const WETH = "0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c";
export const WETHUSDTV2Pair = "0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE";
export const Univ2Router = "0x10ed43c718714eb63d5aa57b78b54704e256024e";
export const DEAD1 = "0x0000000000000000000000000000000000000000"
export const DEAD2 = "0x000000000000000000000000000000000000dead"
export const Unicrypt = "0xC765bddB93b0D1c1A88282BA0fa6B2d00E3e0c83";

// Providers from local node
export const provider = new ethers.providers.JsonRpcProvider(
  process.env.RPC_URL
);

export const wssProvider = new ethers.providers.WebSocketProvider(
  process.env.RPC_URL_WSS
);

export const ERC20Contract = new ethers.Contract(ethers.constants.AddressZero, IERC20, provider);

export const UniswapV2PairContract = new ethers.Contract(
  ethers.constants.AddressZero,
  IUniswapV2Pair,
  provider
);

export let maxBlockNumber = (await wssProvider.getBlock("latest")).number;
export const setMaxBlockNumber = (latestBlockNumber) =>{
  maxBlockNumber = latestBlockNumber;
}

export let nextBlockBaseFee = calcNextBlockBaseFee(await wssProvider.getBlock("latest"));
export const setNextBlockBaseFee = (latestBlock) => {
  nextBlockBaseFee = calcNextBlockBaseFee(latestBlock);
}

export const web3 = new Web3(new Web3.providers.HttpProvider(process.env.RPC_URL));

export let ETHPrice = 0;
export const SetETHPrice = (_ETHPrice) => {
  ETHPrice = _ETHPrice;
}

export let checkedPairs = [];