import { ethers } from "ethers";
import dotenv from "dotenv";
dotenv.config();
import { calcNextBlockBaseFee } from "./utils.js";
import IUniswapV2Pair from "./ABIs/IUniswapV2Pair.js";
import IERC20 from "./ABIs/IERC20.js";
import Web3 from "web3";
// Const addresses on ethereum
export const WETH = "0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7";
export const WETHUSDTV2Pair = "0x0e0100Ab771E9288e0Aa97e11557E6654C3a9665";
export const Univ2Router = "0x7a250d5630b4cf539739df2c5dacb4c659f2488d";
export const DEAD1 = "0x0000000000000000000000000000000000000000"
export const DEAD2 = "0x000000000000000000000000000000000000dead"
export const Unicrypt = "0xa9f6aefa5d56db1205f36c34e6482a6d4979b3bb";

// Providers from local node
export const provider = new ethers.providers.JsonRpcProvider(
  process.env.RPC_URL
);

export const wssProvider = new ethers.providers.WebSocketProvider(
  process.env.RPC_URL_WSS
);

export const ERC20Contract = new ethers.Contract(ethers.constants.AddressZero, IERC20, provider);

export const UniswapV2PairContract = new ethers.Contract(
  ethers.constants.AddressZero,
  IUniswapV2Pair,
  provider
);

export let maxBlockNumber = (await provider.getBlock("latest")).number;
export const setMaxBlockNumber = (latestBlockNumber) =>{
  maxBlockNumber = latestBlockNumber;
}

export let nextBlockBaseFee = calcNextBlockBaseFee(await provider.getBlock("latest"));
export const setNextBlockBaseFee = (latestBlock) => {
  nextBlockBaseFee = calcNextBlockBaseFee(latestBlock);
}

export const web3 = new Web3(new Web3.providers.HttpProvider(process.env.RPC_URL));

export let ETHPrice = 0;
export const SetETHPrice = (_ETHPrice) => {
  ETHPrice = _ETHPrice;
}

export let checkedPairs = [];